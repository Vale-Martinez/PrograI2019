package logica.gestores;

import logica.sorteos.*;
import estructura.LinkedList;

/**
 *
 * @author valem
 */
public class GestorSorteos {
  private LinkedList<Sorteos> listaSorteos;
    
   

}
