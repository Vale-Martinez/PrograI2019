/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import estructura.*;

/**
 *
 * @author valem
 */
public class PRUEBA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Stack s = new Stack();
        DoublyLinkedList d = new DoublyLinkedList();
        LinkedList l =new LinkedList();
        PriorityQueue p =new PriorityQueue();

    }

}
